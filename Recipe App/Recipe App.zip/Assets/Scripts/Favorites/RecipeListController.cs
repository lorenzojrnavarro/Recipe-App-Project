using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecipeListController : FavoritesListController<Recipe>
{
    protected override void Awake()
    {
        base.Awake();
    }
}
