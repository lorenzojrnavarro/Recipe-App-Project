using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AllergenIDs : MonoBehaviour
{
    public int allergenID;

    private void Awake()
    {
       
    }
}
