using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class RecipeManager 
{
    public static Recipe CurrentRecipe { get; set; }
}
