using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecipeDropdown : NonBlockingDropdown<Recipe>
{
    
}
