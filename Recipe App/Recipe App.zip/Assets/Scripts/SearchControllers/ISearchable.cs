using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISearchable
{
    public string Name { get; set; }
}
